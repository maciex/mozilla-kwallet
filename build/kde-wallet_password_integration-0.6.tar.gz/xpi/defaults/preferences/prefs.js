pref("extensions.firefox-kde-wallet.folder", "Firefox");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.kwallet@guillermo.molina.description", "chrome://firefox-kde-wallet/locale/overlay.properties");
